<?php

return [
    'name' => 'Pendapatan'
];
